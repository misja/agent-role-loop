# Herkomst

Bron: https://github.com/misja/agent-role-loop, werkitem #31.
Bewerkt onderwijsvoorbeeld door Misja Hoebe met AI-ondersteuning.
Licentie CC BY-NC-SA 4.0, zie LICENSE.
Procesbasis: ae561f50a45ca42967e4687434cf0d2e8d4f5827; normen/core bevat de ongewijzigde core van die versie.
A/B zijn leeslabels voor codebestanden, geen Git-commits. Lees overdrachten.md voor de scenario-status.
